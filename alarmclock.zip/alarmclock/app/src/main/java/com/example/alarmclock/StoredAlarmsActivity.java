// src/main/java/com/example/alarmclock/StoredAlarmsActivity.java
package com.example.alarmclock;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class StoredAlarmsActivity extends AppCompatActivity {

    private ListView lvAlarms;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stored_alarms);

        lvAlarms = findViewById(R.id.lv_alarms);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        loadAlarms();
    }

    private void loadAlarms() {
        Set<String> alarms = sharedPreferences.getStringSet("alarms", new HashSet<>());
        ArrayList<String> alarmsList = new ArrayList<>(alarms);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, alarmsList);
        lvAlarms.setAdapter(adapter);
    }
}
