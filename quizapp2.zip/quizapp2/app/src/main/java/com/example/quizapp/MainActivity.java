package com.example.quizapp;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView questionTextView;
    private RadioGroup optionsRadioGroup;
    private RadioButton option1RadioButton;
    private RadioButton option2RadioButton;
    private RadioButton option3RadioButton;
    private RadioButton option4RadioButton;
    private Button nextButton;
    private ProgressBar timerProgressBar;

    private String[] questions = {
            "What is the smallest planet in our solar system?",
            "Who wrote 'To Kill a Mockingbird'?",
            "What is the hardest natural substance on Earth?",
            "What year did the Titanic sink?",
            "What is the largest ocean on Earth?"
    };

    private String[][] options = {
            {"Mercury", "Mars", "Venus", "Earth"},
            {"Harper Lee", "J.K. Rowling", "Ernest Hemingway", "Mark Twain"},
            {"Diamond", "Ruby", "Sapphire", "Emerald"},
            {"1912", "1905", "1898", "1923"},
            {"Pacific Ocean", "Atlantic Ocean", "Indian Ocean", "Arctic Ocean"}
    };


    private String[] answers = {
            "Paris", "4", "Tokyo", "Jupiter", "H2O", "1912", "William Shakespeare",
            "Rome", "2", "8", "Ottawa", "Leonardo da Vinci", "100", "Avocados",
            "Madrid", "Albert Einstein", "Nile", "Canberra", "New Delhi", "Blue Whale",
            "Moscow", "Oxygen", "Charles Babbage", "Diamond", "Alexander Graham Bell"
    };

    private int currentQuestionIndex = 0;
    private int score = 0;
    private CountDownTimer timer;
    private static final long TIMER_DURATION = 10000; // 10 seconds for each question

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        questionTextView = findViewById(R.id.questionTextView);
        optionsRadioGroup = findViewById(R.id.optionsRadioGroup);
        option1RadioButton = findViewById(R.id.option1RadioButton);
        option2RadioButton = findViewById(R.id.option2RadioButton);
        option3RadioButton = findViewById(R.id.option3RadioButton);
        option4RadioButton = findViewById(R.id.option4RadioButton);
        nextButton = findViewById(R.id.nextButton);
        timerProgressBar = findViewById(R.id.timerProgressBar);

        showNextQuestion();

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
                currentQuestionIndex++;
                if (currentQuestionIndex < questions.length) {
                    showNextQuestion();
                } else {
                    showFinalScore();
                }
            }
        });
    }

    private void showNextQuestion() {
        optionsRadioGroup.clearCheck();
        questionTextView.setText(questions[currentQuestionIndex]);
        option1RadioButton.setText(options[currentQuestionIndex][0]);
        option2RadioButton.setText(options[currentQuestionIndex][1]);
        option3RadioButton.setText(options[currentQuestionIndex][2]);
        option4RadioButton.setText(options[currentQuestionIndex][3]);

        if (timer != null) {
            timer.cancel();
        }
        timerProgressBar.setProgress(0);
        timer = new CountDownTimer(TIMER_DURATION, 100) {
            @Override
            public void onTick(long millisUntilFinished) {
                int progress = (int) ((TIMER_DURATION - millisUntilFinished) / (float) TIMER_DURATION * 100);
                timerProgressBar.setProgress(progress);
            }

            @Override
            public void onFinish() {
                checkAnswer();
                currentQuestionIndex++;
                if (currentQuestionIndex < questions.length) {
                    showNextQuestion();
                } else {
                    showFinalScore();
                }
            }
        }.start();
    }

    private void checkAnswer() {
        int selectedOptionId = optionsRadioGroup.getCheckedRadioButtonId();
        if (selectedOptionId != -1) {
            RadioButton selectedRadioButton = findViewById(selectedOptionId);
            String selectedAnswer = selectedRadioButton.getText().toString();
            if (selectedAnswer.equals(answers[currentQuestionIndex])) {
                score++;
            }
        } else {
            Toast.makeText(this, "Please select an answer", Toast.LENGTH_SHORT).show();
        }
    }

    private void showFinalScore() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Quiz Finished");
        builder.setMessage("Your score: " + score + " out of " + questions.length);
        builder.setPositiveButton("OK", null);
        builder.show();
    }
}